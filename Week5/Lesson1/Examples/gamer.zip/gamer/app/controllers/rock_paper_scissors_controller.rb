class RockPaperScissorsController < ApplicationController
  def new
  	# Displays the view to pick a choice
    @options = get_data
  end

  # GET /rock_paper_scissors/:id
  def show
    @user_choice = params[:id]
    options = get_data

    @app_choice = options[rand(3)]

    @result = compare(@user_choice, @app_choice)
  end

  def something
  	@data = get_data
  end

  private
    def compare(user_choice, app_choice)
      beats = {
        "rock" => "scissors",
        "paper" => "rock",
        "scissors" => "paper"
      }

      options = get_data

      user = options[user_choice.to_i]

      if beats[user] == app_choice
        "User won"
      else
        "Computer won"
      end
    end


  	def get_data
  		['rock', 'paper', 'scissors']
  	end
end
